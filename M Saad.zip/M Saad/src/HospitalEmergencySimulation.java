import java.util.*;

class Patient {
    int id, age, roomNumber = -1;
    String name, diagnosis, assignedDoctorId, severity;
    boolean discharged = false;
    Patient next;
    Patient(int id, String name, int age, String severity, String diagnosis) {
        this.id=id; this.name=name; this.age=age; this.severity=severity; this.diagnosis=diagnosis;
    }
    public String toString() {
        return String.format("[ID:%d|%s|Age:%d|%s|Dx:%s|Room:%s|Dr:%s]",
                id,name,age,severity,diagnosis,roomNumber==-1?"None":roomNumber,assignedDoctorId==null?"None":assignedDoctorId);
    }
}

class Doctor {
    String id, name, specialty; boolean available=true;
    Doctor(String id, String name, String specialty) { this.id=id; this.name=name; this.specialty=specialty; }
    public String toString() { return String.format("[Dr.%s|%s|%s|%s]",id,name,specialty,available?"Available":"Busy"); }
}

class TreatmentAction {
    String type, detail; int patientId;
    TreatmentAction(String type, int patientId, String detail) { this.type=type; this.patientId=patientId; this.detail=detail; }
    public String toString() { return "("+type+"|PatientID:"+patientId+"|"+detail+")"; }
}

class PatientLinkedList {
    Patient head; int size;
    void add(Patient p) { if(head==null){head=p;}else{Patient c=head;while(c.next!=null)c=c.next;c.next=p;} size++; }
    Patient findById(int id) { Patient c=head; while(c!=null){if(c.id==id)return c;c=c.next;} return null; }
    void remove(int id) {
        if(head==null)return;
        if(head.id==id){head=head.next;size--;return;}
        Patient c=head;
        while(c.next!=null){if(c.next.id==id){c.next=c.next.next;size--;return;}c=c.next;}
    }
    void display() {
        if(head==null){System.out.println("  No patient records.");return;}
        Patient c=head; while(c!=null){System.out.println("  "+c);c=c.next;}
    }
}

class EmergencyPriorityQueue {
    ArrayList<Patient> heap=new ArrayList<>();
    int priority(String s) { return s.equals("CRITICAL")?3:s.equals("SERIOUS")?2:1; }
    void enqueue(Patient p) {
        heap.add(p); int i=heap.size()-1;
        while(i>0){int par=(i-1)/2;if(priority(heap.get(par).severity)<priority(heap.get(i).severity)){Collections.swap(heap,par,i);i=par;}else break;}
    }
    Patient dequeue() {
        if(heap.isEmpty())return null;
        Patient top=heap.get(0); Patient last=heap.remove(heap.size()-1);
        if(!heap.isEmpty()){heap.set(0,last);heapifyDown(0);}
        return top;
    }
    void heapifyDown(int i) {
        int n=heap.size(),lg=i,l=2*i+1,r=2*i+2;
        if(l<n&&priority(heap.get(l).severity)>priority(heap.get(lg).severity))lg=l;
        if(r<n&&priority(heap.get(r).severity)>priority(heap.get(lg).severity))lg=r;
        if(lg!=i){Collections.swap(heap,i,lg);heapifyDown(lg);}
    }
    boolean isEmpty(){return heap.isEmpty();} int size(){return heap.size();}
    void display() {
        if(heap.isEmpty()){System.out.println("  Emergency queue empty.");return;}
        ArrayList<Patient> copy=new ArrayList<>(heap);
        copy.sort((a,b)->priority(b.severity)-priority(a.severity));
        for(Patient p:copy)System.out.println("  "+p);
    }
}

class WaitingQueue {
    LinkedList<Patient> queue=new LinkedList<>();
    void enqueue(Patient p){queue.addLast(p);} Patient dequeue(){return queue.isEmpty()?null:queue.removeFirst();}
    boolean isEmpty(){return queue.isEmpty();} int size(){return queue.size();}
    void display(){if(queue.isEmpty()){System.out.println("  Waiting room empty.");return;}int i=1;for(Patient p:queue)System.out.println("  "+i+++". "+p);}
}

class TreatmentStack {
    ArrayList<TreatmentAction> stack=new ArrayList<>();
    void push(TreatmentAction a){stack.add(a);}
    TreatmentAction pop(){return stack.isEmpty()?null:stack.remove(stack.size()-1);}
    boolean isEmpty(){return stack.isEmpty();}
    void display(){if(stack.isEmpty()){System.out.println("  No treatment history.");return;}for(int i=stack.size()-1;i>=0;i--)System.out.println("  "+stack.get(i));}
}

class BSTNode {
    int appointmentId, patientId; String dateTime, doctorId; BSTNode left,right;
    BSTNode(int aId,int pId,String dt,String dId){appointmentId=aId;patientId=pId;dateTime=dt;doctorId=dId;}
    public String toString(){return String.format("[ApptID:%d|PatientID:%d|Dr:%s|Time:%s]",appointmentId,patientId,doctorId,dateTime);}
}

class AppointmentBST {
    BSTNode root; int nextApptId=1;
    BSTNode insert(BSTNode n,int aId,int pId,String dt,String dId){
        if(n==null)return new BSTNode(aId,pId,dt,dId);
        if(aId<n.appointmentId)n.left=insert(n.left,aId,pId,dt,dId);
        else if(aId>n.appointmentId)n.right=insert(n.right,aId,pId,dt,dId);
        return n;
    }
    int schedule(int pId,String dt,String dId){int id=nextApptId++;root=insert(root,id,pId,dt,dId);return id;}
    void inorder(BSTNode n){if(n==null)return;inorder(n.left);System.out.println("  "+n);inorder(n.right);}
    void displayAll(){if(root==null){System.out.println("  No appointments scheduled.");return;}inorder(root);}
}

class RoomManager {
    int totalRooms; boolean[] occupied;
    RoomManager(int n){totalRooms=n;occupied=new boolean[n+1];}
    int assignRoom(){for(int i=1;i<=totalRooms;i++)if(!occupied[i]){occupied[i]=true;return i;}return -1;}
    void releaseRoom(int r){if(r>=1&&r<=totalRooms)occupied[r]=false;}
    void displayStatus(){System.out.println("  Room Status:");for(int i=1;i<=totalRooms;i++)System.out.printf("    Room %2d: %s%n",i,occupied[i]?"OCCUPIED":"FREE");}
    int availableCount(){int c=0;for(int i=1;i<=totalRooms;i++)if(!occupied[i])c++;return c;}
}

class ReferralResolver {
    static Map<String,String> chain=new HashMap<>();
    static { chain.put("CARDIOLOGIST","SURGEON"); chain.put("NEUROLOGIST","SURGEON"); chain.put("ORTHOPEDIC","SURGEON"); chain.put("SURGEON","GENERAL"); }
    static Doctor resolve(String spec,Map<String,Doctor> dMap,int depth){
        if(depth>5)return null;
        System.out.println("    [Referral] Looking for: "+spec);
        for(Doctor d:dMap.values())if(d.specialty.equals(spec)&&d.available)return d;
        if(chain.containsKey(spec)){System.out.println("    [Referral] No "+spec+" available. Trying referral...");return resolve(chain.get(spec),dMap,depth+1);}
        return null;
    }
}

class HospitalSystem {
    PatientLinkedList patientRecords=new PatientLinkedList();
    EmergencyPriorityQueue emergencyPQ=new EmergencyPriorityQueue();
    WaitingQueue waitingRoom=new WaitingQueue();
    TreatmentStack treatmentHistory=new TreatmentStack();
    Map<Integer,Patient> patientMap=new HashMap<>();
    Map<String,Doctor> doctorMap=new HashMap<>();
    AppointmentBST apptBST=new AppointmentBST();
    RoomManager roomManager=new RoomManager(10);
    int nextPatientId=1001;

    void seedDoctors(){
        String[][] d={{"D01","Dr. Ahmed","GENERAL"},{"D02","Dr. Sara","CARDIOLOGIST"},{"D03","Dr. Bilal","NEUROLOGIST"},{"D04","Dr. Nadia","ORTHOPEDIC"},{"D05","Dr. Tariq","SURGEON"},{"D06","Dr. Faiza","GENERAL"}};
        for(String[] x:d){Doctor doc=new Doctor(x[0],x[1],x[2]);doctorMap.put(x[0],doc);}
        System.out.println("  6 doctors registered.");
    }

    Patient registerPatient(String name,int age,String severity,String diagnosis){
        Patient p=new Patient(nextPatientId++,name,age,severity,diagnosis);
        patientRecords.add(p); patientMap.put(p.id,p);
        System.out.printf("  Patient registered: %s (ID:%d)%n",name,p.id); return p;
    }

    void triagePatient(int id){
        Patient p=patientMap.get(id);
        if(p==null){System.out.println("  Patient not found.");return;}
        if(p.severity.equals("CRITICAL")||p.severity.equals("SERIOUS")){emergencyPQ.enqueue(p);System.out.printf("  %s added to EMERGENCY queue (%s).%n",p.name,p.severity);}
        else{waitingRoom.enqueue(p);System.out.printf("  %s added to WAITING room (%s).%n",p.name,p.severity);}
    }

    void processNextEmergency(){Patient p=emergencyPQ.dequeue();if(p==null){System.out.println("  No emergency patients.");return;}System.out.println("  Processing emergency: "+p);assignDoctorAndRoom(p);}
    void processNextWaiting(){Patient p=waitingRoom.dequeue();if(p==null){System.out.println("  Waiting room empty.");return;}System.out.println("  Processing waiting patient: "+p);assignDoctorAndRoom(p);}

    void assignDoctorAndRoom(Patient p){
        Doctor doc=null;
        for(Doctor d:doctorMap.values())if(d.available){doc=d;break;}
        if(doc==null){System.out.println("  No doctor available.");return;}
        doc.available=false; p.assignedDoctorId=doc.id;
        treatmentHistory.push(new TreatmentAction("ASSIGN_DOCTOR",p.id,"Doctor:"+doc.id+"("+doc.name+")"));
        System.out.printf("  Assigned %s to patient %s.%n",doc.name,p.name);
        int room=roomManager.assignRoom();
        if(room==-1){System.out.println("  No room available.");}
        else{p.roomNumber=room;treatmentHistory.push(new TreatmentAction("ASSIGN_ROOM",p.id,"Room:"+room));System.out.printf("  Assigned Room %d to %s.%n",room,p.name);}
    }

    void requestSpecialist(int patientId,String spec){
        Patient p=patientMap.get(patientId);
        if(p==null){System.out.println("  Patient not found.");return;}
        spec=spec.toUpperCase();
        System.out.println("  Resolving specialist referral...");
        Doctor found=ReferralResolver.resolve(spec,doctorMap,0);
        if(found==null){System.out.println("  No specialist available.");}
        else{found.available=false;String old=p.assignedDoctorId;if(old!=null&&doctorMap.containsKey(old))doctorMap.get(old).available=true;p.assignedDoctorId=found.id;treatmentHistory.push(new TreatmentAction("SPECIALIST_REFERRAL",p.id,"Specialist:"+found.name+"("+found.specialty+")"));System.out.printf("  %s referred to %s (%s).%n",p.name,found.name,found.specialty);}
    }

    void dischargePatient(int id){
        Patient p=patientMap.get(id);
        if(p==null){System.out.println("  Patient not found.");return;}
        if(p.discharged){System.out.println("  Already discharged.");return;}
        if(p.assignedDoctorId!=null&&doctorMap.containsKey(p.assignedDoctorId))doctorMap.get(p.assignedDoctorId).available=true;
        if(p.roomNumber!=-1)roomManager.releaseRoom(p.roomNumber);
        p.discharged=true;
        treatmentHistory.push(new TreatmentAction("DISCHARGE",p.id,"Room:"+p.roomNumber+" released, Dr:"+p.assignedDoctorId+" freed"));
        System.out.printf("  Patient %s (ID:%d) discharged.%n",p.name,id);
    }

    void undoLastAction(){
        TreatmentAction a=treatmentHistory.pop();
        if(a==null){System.out.println("  Nothing to undo.");return;}
        System.out.println("  Undoing: "+a);
        Patient p=patientMap.get(a.patientId); if(p==null)return;
        switch(a.type){
            case "ASSIGN_DOCTOR": String dId=a.detail.split(":")[1].split("\\(")[0];if(doctorMap.containsKey(dId))doctorMap.get(dId).available=true;p.assignedDoctorId=null;System.out.println("  Doctor assignment reverted.");break;
            case "ASSIGN_ROOM": int room=Integer.parseInt(a.detail.split(":")[1]);roomManager.releaseRoom(room);p.roomNumber=-1;System.out.println("  Room assignment reverted.");break;
            case "DISCHARGE": p.discharged=false;System.out.println("  Discharge reverted.");break;
            case "SPECIALIST_REFERRAL": if(p.assignedDoctorId!=null&&doctorMap.containsKey(p.assignedDoctorId))doctorMap.get(p.assignedDoctorId).available=true;p.assignedDoctorId=null;System.out.println("  Specialist referral reverted.");break;
        }
    }

    void scheduleAppointment(int pId,String dt,String dId){
        if(!patientMap.containsKey(pId)){System.out.println("  Patient not found.");return;}
        if(!doctorMap.containsKey(dId)){System.out.println("  Doctor not found.");return;}
        int id=apptBST.schedule(pId,dt,dId);
        System.out.printf("  Appointment scheduled (ID:%d) for PatientID:%d with %s at %s.%n",id,pId,dId,dt);
    }

    void lookupPatient(int id){Patient p=patientMap.get(id);System.out.println(p==null?"  Patient not found.":"  "+p);}
    void lookupDoctor(String id){Doctor d=doctorMap.get(id);System.out.println(d==null?"  Doctor not found.":"  "+d);}

    void statusReport(){
        System.out.println("\n========== HOSPITAL STATUS REPORT ==========");
        System.out.println("Total Patients    : "+patientRecords.size);
        System.out.println("Emergency Queue   : "+emergencyPQ.size());
        System.out.println("Waiting Room      : "+waitingRoom.size());
        System.out.println("Available Rooms   : "+roomManager.availableCount()+"/10");
        long avail=doctorMap.values().stream().filter(d->d.available).count();
        System.out.println("Available Doctors : "+avail+"/"+doctorMap.size());
        System.out.println("Treatment Actions : "+treatmentHistory.stack.size());
        System.out.println("\n-- Patient Records --"); patientRecords.display();
        System.out.println("\n-- Emergency Queue --"); emergencyPQ.display();
        System.out.println("\n-- Waiting Room --"); waitingRoom.display();
        System.out.println("\n-- Doctors --"); doctorMap.values().forEach(d->System.out.println("  "+d));
        System.out.println("\n-- Appointments --"); apptBST.displayAll();
        System.out.println("\n-- Treatment History --"); treatmentHistory.display();
        System.out.println("\n-- Rooms --"); roomManager.displayStatus();
        System.out.println("=============================================\n");
    }
}

public class HospitalEmergencySimulation {
    static Scanner sc=new Scanner(System.in);
    static HospitalSystem hospital=new HospitalSystem();

    public static void main(String[] args){
        System.out.println("=== HOSPITAL EMERGENCY MANAGEMENT SYSTEM ===");
        hospital.seedDoctors(); loadSamplePatients(); System.out.println("  Sample patients loaded.\n");
        boolean running=true;
        while(running){
            printMenu(); System.out.print("Enter choice: "); String input=sc.nextLine().trim(); System.out.println();
            switch(input){
                case "1": registerPatientMenu(); break;
                case "2": triageMenu(); break;
                case "3": hospital.processNextEmergency(); break;
                case "4": hospital.processNextWaiting(); break;
                case "5": lookupPatientMenu(); break;
                case "6": dischargeMenu(); break;
                case "7": lookupDoctorMenu(); break;
                case "8": specialistReferralMenu(); break;
                case "9": hospital.treatmentHistory.display(); break;
                case "10": hospital.undoLastAction(); break;
                case "11": scheduleApptMenu(); break;
                case "12": hospital.apptBST.displayAll(); break;
                case "13": System.out.println("Emergency Queue:"); hospital.emergencyPQ.display(); break;
                case "14": System.out.println("Waiting Room:"); hospital.waitingRoom.display(); break;
                case "15": hospital.roomManager.displayStatus(); break;
                case "16": hospital.statusReport(); break;
                case "17": runDemoScenario(); break;
                case "0": running=false; System.out.println("Goodbye!"); break;
                default: System.out.println("  Invalid choice.");
            }
            System.out.println();
        }
    }

    static void printMenu(){
        System.out.println("--- MAIN MENU ---");
        System.out.println("1.Register Patient  2.Triage  3.Process Emergency  4.Process Waiting");
        System.out.println("5.Lookup Patient    6.Discharge  7.Lookup Doctor   8.Specialist");
        System.out.println("9.Treatment History 10.Undo  11.Schedule Appt  12.View Appts");
        System.out.println("13.Emergency Queue  14.Waiting Room  15.Rooms  16.Status  17.Demo  0.Exit");
    }

    static void registerPatientMenu(){
        System.out.print("Name: "); String name=sc.nextLine().trim();
        System.out.print("Age: "); int age=Integer.parseInt(sc.nextLine().trim());
        System.out.print("Severity (1=CRITICAL,2=SERIOUS,3=STABLE): "); int s=Integer.parseInt(sc.nextLine().trim());
        String sev=s==1?"CRITICAL":s==2?"SERIOUS":"STABLE";
        System.out.print("Diagnosis: "); String diag=sc.nextLine().trim();
        hospital.registerPatient(name,age,sev,diag);
    }

    static void triageMenu(){System.out.print("Patient ID: ");hospital.triagePatient(Integer.parseInt(sc.nextLine().trim()));}
    static void lookupPatientMenu(){System.out.print("Patient ID: ");hospital.lookupPatient(Integer.parseInt(sc.nextLine().trim()));}
    static void dischargeMenu(){System.out.print("Patient ID: ");hospital.dischargePatient(Integer.parseInt(sc.nextLine().trim()));}
    static void lookupDoctorMenu(){System.out.print("Doctor ID: ");hospital.lookupDoctor(sc.nextLine().trim());}

    static void specialistReferralMenu(){
        System.out.print("Patient ID: "); int pid=Integer.parseInt(sc.nextLine().trim());
        System.out.print("Specialty (GENERAL/CARDIOLOGIST/NEUROLOGIST/ORTHOPEDIC/SURGEON): ");
        hospital.requestSpecialist(pid,sc.nextLine().trim());
    }

    static void scheduleApptMenu(){
        System.out.print("Patient ID: "); int pid=Integer.parseInt(sc.nextLine().trim());
        System.out.print("Doctor ID: "); String did=sc.nextLine().trim();
        System.out.print("Date/Time: "); hospital.scheduleAppointment(pid,sc.nextLine().trim(),did);
    }

    static void loadSamplePatients(){
        String[][] data={{"Ali Hassan","34","CRITICAL","Heart Attack"},{"Sara Khan","52","SERIOUS","Stroke"},{"Usman Tariq","28","STABLE","Fracture"},{"Amina Bibi","67","CRITICAL","Cardiac Arrest"},{"Zain Malik","19","STABLE","Appendicitis"},{"Hina Qureshi","45","SERIOUS","Internal Bleeding"}};
        for(String[] d:data){Patient p=hospital.registerPatient(d[0],Integer.parseInt(d[1]),d[2],d[3]);hospital.triagePatient(p.id);}
        hospital.scheduleAppointment(1001,"2025-07-10 09:00","D02");
        hospital.scheduleAppointment(1003,"2025-07-11 11:00","D04");
        hospital.scheduleAppointment(1002,"2025-07-12 14:30","D03");
    }

    static void runDemoScenario(){
        System.out.println("=== DEMO SCENARIO ===");
        System.out.println("Step 1: Process top emergency"); hospital.processNextEmergency();
        System.out.println("\nStep 2: Process another emergency"); hospital.processNextEmergency();
        System.out.println("\nStep 3: Process waiting patient"); hospital.processNextWaiting();
        System.out.println("\nStep 4: Request cardiologist for patient 1001"); hospital.requestSpecialist(1001,"CARDIOLOGIST");
        System.out.println("\nStep 5: Treatment history"); hospital.treatmentHistory.display();
        System.out.println("\nStep 6: Undo last action"); hospital.undoLastAction();
        System.out.println("\nStep 7: Discharge patient 1004"); hospital.dischargePatient(1004);
        System.out.println("\nStep 8: Schedule appointment"); hospital.scheduleAppointment(1005,"2025-07-15 10:00","D05");
        System.out.println("\nStep 9: Appointments"); hospital.apptBST.displayAll();
        System.out.println("\nStep 10: Status report"); hospital.statusReport();
    }
}